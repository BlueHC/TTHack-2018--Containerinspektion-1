#!/usr/bin/env python
# -*- coding: utf-8 -*-

# 
#
#
# start local development server from the path of this file via
#      python pred_service.py
#
# call via:
#      curl -F "file=@/path/to/image.jpg"   localhost:5000/pred/img
#
# or open
# 		http://localhost:5000/pred/img
# in web browser to use via upload form
#
# json:

import os

from flask import Flask, request, redirect, url_for, Response
from werkzeug.utils import secure_filename
from flask import send_from_directory, jsonify
import numpy as np
import h5py
import keras
import keras.backend as K
#import tensorflow as tf
from keras.models import load_model
from keras.models import Model
from container_check.losses import grid_cell_detection_loss
from container_check.prediction_processing import visualize_predictions
from container_check.utils import resize_image
from math import ceil, exp
import cv2
import numpy as np
import pydot
from PIL import Image

from flask_restplus import Resource, Api, fields

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = "./images"
MODEL_DIR = "./model"
MODEL_FILE = "deployment_model_final_version.h5"


api = Api(app,
          title="Transport container image analysis",
          version="0.1",
          description="API for analysing defects on transport container images"
          )
          
ns = api.namespace("pred", description="Image analysis services")

ALLOWED_EXTENSIONS = ["jpg", "jpeg"]	
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
           
def output_html(html_string, code, headers=None):
    """create a response object sending a html page for a flask restful api"""
    resp = Response(html_string, mimetype='text/html', headers=headers)
    resp.status_code = code
    return resp

@ns.route('/img')
class ImageAnalyis2Service(Resource):
	def post(self):
		# check if the post request has the file part
		if 'file' not in request.files:
			app.logger.info('No file part')
			return redirect(request.url)
		file = request.files['file']
		app.logger.info("Found file" + str(type(file)))
		# if user does not select file, browser also
		# submit a empty part without filename
		if file.filename == '':
			app.logger.info('No selected file')
			return redirect(request.url)
		if file and allowed_file(file.filename):
			####
			#    ENTER OWN CODE HERE AND EDIT RESPONSE AS YOU LIKE
			####
			detection_model = load_model(os.path.join(MODEL_DIR, MODEL_FILE),  custom_objects={'grid_cell_detection_loss': grid_cell_detection_loss})

			pred_vis = visualize_predictions(detection_model, classes=['rust', 'dent', 'hook'], pred_array_length=8)
			filename = secure_filename(file.filename)
			file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
			pred_vis.single_image_detection(os.path.join(app.config['UPLOAD_FOLDER'], filename), threshold = 0.9999)
			annotated_image = pred_vis.img
			im = Image.fromarray(annotated_image)
			im.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

			### Save crops and add their download urls to crop_urls dict
			crop_urls = {}
			for key, im_array in pred_vis.crops.items():
				im = Image.fromarray(im_array)
				crop_fname = key.replace('. ', '_') + '.jpg'
				im.save(os.path.join(app.config['UPLOAD_FOLDER'], crop_fname))
				crop_urls[key] = api.url_for(DownloadImage, filename = crop_fname)
			dictionary = {'url': api.url_for(DownloadImage, filename=filename), 'damages': pred_vis.damages, 'crop_urls': crop_urls}
			del pred_vis

			return jsonify(dictionary)

	def get(self):
		return output_html('''
		<!doctype html>
		<title>Upload new File</title>
		<h1>Upload new File</h1>
		<form method=post enctype=multipart/form-data>
		  <p><input type=file name=file>
			 <input type=submit value=Upload>
		</form>
		''', 200)

@ns.route("/img/download/<filename>")
class DownloadImage(Resource):
	def get(self, filename):	
		return send_from_directory(app.config['UPLOAD_FOLDER'],
                               filename)
                               
'''
# Alternative
@ns.route("/img")
class ImageAnalysisService(Resource):
	"""API Resource for posting images and getting predictions"""
	
	
	def post(self):
		"""Send image and get analysis results
		
		expects a jpg image given as request data.... (encoding?)
		"""
		app.logger.info("CALLING PREDICTION SERVICE")
		#raise NotImplementedError
		data = request.data
		
		
		"""
		  sess = tf.Session()
  print("Tensorflow session ready")
  node_lookup = NodeLookup()
  print("Node lookup loaded")
  # Runs the softmax tensor by feeding the image_data as input to the graph.
  softmax_tensor = sess.graph.get_tensor_by_name('final_result:0')
predictions = sess.run(softmax_tensor, {'DecodeJpeg/contents:0': image_data})
		"""
		
		# json_data = request.get_json(force=True)
		
		return {"Test": "test"}
'''		

if __name__ == '__main__':
    app.logger.info("##### START APP #####")
    app.run(host="0.0.0.0", debug=True)		
