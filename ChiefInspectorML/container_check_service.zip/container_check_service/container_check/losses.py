import tensorflow as tf
import keras.backend as K

BATCH_SIZE = 4



def grid_cell_detection_loss(true, pred):
    """Computes the object detection loss on for a predicted grid cell image"""
    transform_constant = tf.divide(tf.constant(.1), tf.constant(.9))
    obj_prob_true = true[..., 0]
    obj_prob_pred = K.sigmoid(pred[..., 0])
    
    xy_pos_true = true[..., 1:3]
    xy_pos_pred = K.exp(pred[..., 1:3])
    
    hw_pos_true = true[..., 3:5]
    #hw_pos_pred = K.exp(pred[..., 3:5])
    hw_pos_pred = K.sigmoid(pred[..., 3:5])
    
    class_true = true[..., 5:]
    class_pred = K.exp(pred[..., 5:])


    
    pos_loss = tf.multiply(tf.reduce_sum(K.square(tf.subtract(xy_pos_true, xy_pos_pred))), obj_prob_true)
    
    size_loss = tf.multiply(tf.reduce_sum(K.square(tf.subtract(xy_pos_true, xy_pos_pred))), obj_prob_true)
    
    class_loss = tf.multiply(tf.reduce_sum(K.square(tf.subtract(class_true, class_pred))), obj_prob_true)
    
    total_loss = tf.add(tf.add(tf.add(obj_prob_loss, pos_loss), size_loss), class_loss)
    
    return total_loss



	

