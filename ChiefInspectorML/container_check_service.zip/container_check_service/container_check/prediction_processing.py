import os
import urllib.request
import time
import numpy as np
import pandas as pd
from math import ceil, exp
import cv2
#import matplotlib.pyplot as plt
from container_check.utils import sigmoid, resize_image
from container_check.data_ingestion import data_generator
PROJECT_DIR = os.pardir



class visualize_predictions():
    """Works only with quadratic images at current state
    :param dataset_key is a tuple containing the dataset name and subset key
    """
    def __init__(self, model, classes=None, dataset_key=None, cell_size=32, pred_array_length=7, denormalize_img_array=True):
        self.model = model
        self.classes = classes
        if (not dataset_key is None):
            assert isinstance(dataset_key, tuple)
            self.data_gen = data_generator(dataset_key[0], 1, dataset_key[1])
        self.cell_size = cell_size
        self.pred_array_length = pred_array_length
        self.denormalize_img_array = denormalize_img_array

    def single_image_detection(self, img_path, threshold=0.8, rotate=2):
        self.threshold = threshold
        img_array = cv2.imread(img_path)
        print(type(img_array))
        img_array = resize_image(img_array, rotate=rotate)
        img_array = cv2.cvtColor(img_array, cv2.COLOR_BGR2RGB)
        img_array = img_array / 255.
        input_array = img_array.reshape((1, img_array.shape[0], img_array.shape[1], 3))
        predictions = self.model.predict(input_array)
        self.draw_predictions(img_array, predictions)
        
    def video_detection(self, video_path, threshold=0.9999999, rotate = 3, save=False):
        self.threshold = threshold
        vidcap = cv2.VideoCapture(video_path)
        success = True
        fourcc = cv2.VideoWriter_fourcc(*'XVID')
        if save:
            out = cv2.VideoWriter(video_path + '_annotated.avi',fourcc, 20.0, (608,608))
        while success:
            success, img = vidcap.read()
            if (not success):
                break
            img = resize_image(img, rotate=rotate)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img = img / 255.
            input_array = img.reshape((1, 608, 608, 3))
            #start = time.time()
            predictions = self.model.predict(input_array)
            #print('Prediction time:', time.time() - start)
            self.draw_predictions(img, predictions, show_image=False)
            img = cv2.cvtColor(self.img, cv2.COLOR_RGB2BGR)
            if save:
                out.write(img)
            
            
            cv2.imshow(video_path.split(os.sep)[-1],img)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        vidcap.release()
        if save:
            out.release()
        cv2.destroyAllWindows()
        
    def mobile_stream_detection(self, url, threshold=0.9999999, rotate=False, time_sleep=0.1):
        """rotate: How often to rotate image clockwise by 90°"""
        self.threshold = threshold
        while True:
            imgResp = urllib.request.urlopen(url)
            # Numpy to convert into a array
            imgNp = np.array(bytearray(imgResp.read()),dtype=np.uint8)
            
            # Finally decode the array to OpenCV usable format ;) 
            img = cv2.imdecode(imgNp, -1)
            img = resize_image(img, rotate=rotate)
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img = img / 255.
            input_array = img.reshape((1, 608, 608, 3))
            predictions = self.model.predict(inp_array)
            self.draw_predictions(img, predictions)
            img = cv2.cvtColor(self.img, cv2.COLOR_RGB2BGR)
            cv2.imshow('IPWebcam', img)

            #To give the processor some less stress
            time.sleep(time_sleep) 

            # Quit if q is pressed
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        cv2.destroyAllWindows()   
            

    def predict_and_show(self, threshold=0.8, return_values=False):
        self.threshold = threshold
        X, y = next(self.data_gen)
        X, y = np.array(X[0]), np.array(y[0])
        X_input = X.reshape((1, X.shape[0], X.shape[1], 3))
        prediction = self.model.predict(X_input)
        self.draw_predictions(X, prediction)
        if return_values:
            y = y.reshape((self.pred_array_length,))
            prediction = np.array(self.process_pred(prediction.reshape(self.pred_array_length, ))).reshape((self.pred_array_length,))
            df_data = np.stack((y, prediction))
            cols = ['object_prob', 'bbox_x', 'bbox_y', 'rel_bbox_h', 'rel_bbox_w'] + [x + '_prob' for x in self.classes]
            df = pd.DataFrame(data = df_data, 
                              columns = cols,
                              index = ['Ground truth', 'Prediction']
                              )
            return df
        

    def draw_predictions(self, img_array, predictions, true_labels=False, show_image=False):
        """Set true_labels=True if predictions are the true labels"""
        self.grid_cells = int((img_array.shape[0] / self.cell_size) * (img_array.shape[1] / self.cell_size))
        self.cells_per_side = int((img_array.shape[0] / self.cell_size))
        self.true_labels = true_labels
        
        if self.denormalize_img_array:
            self.img = (img_array * 255.).astype(np.uint8)
        else:
            self.img = img_array.astype(np.unit8)
        
        pred_arrays = self.single_pred_array_to_arrays(
                                predictions.reshape(
                                       self.grid_cells * self.pred_array_length,
                                       )
                                )
        self.add_bboxes(pred_arrays)
        if show_image:
            pass
        

    def add_bboxes(self, pred_arrays):
        """Adds bounding boxes to the image array"""
       
        damage_count = 0
        self.damages={}
        self.crops = {}

        for i in range(len(pred_arrays)):
            pred = pred_arrays[i]
            processed_pred = self.process_pred(pred)
            obj_prob, bbox_x, bbox_y, rel_bbox_h, rel_bbox_w = processed_pred[:5]
            probs = processed_pred[5:]
            #obj_prob, bbox_x, bbox_y, rel_bbox_h, rel_bbox_w, silver_prob, red_prob = self.process_pred(pred)
            if obj_prob >= self.threshold:
                #if silver_prob > red_prob:
                damage_count += 1
                max_class = self.classes[probs.index(max(probs))]
                key = str(damage_count) +'. ' + max_class
                self.damages[key] = max(probs)
                line_color = (255, 255, 255)
                #else:
                #    line_color = (255, 0, 0)
                upper_left_pix, lower_right_pix = self.calc_pixel_pos(i, bbox_x, bbox_y, rel_bbox_h, rel_bbox_w)
                print(type(self.img))
                print(self.img.shape, upper_left_pix, lower_right_pix)
                self.crops[key] = self.img[lower_right_pix[1]:upper_left_pix[1], upper_left_pix[0]:lower_right_pix[0]]
                self.img = cv2.rectangle(self.img, upper_left_pix, lower_right_pix, line_color, 1)
                self.img = cv2.putText(self.img, max_class, lower_right_pix, cv2.FONT_HERSHEY_SIMPLEX, .5, line_color, 2, cv2.LINE_AA)
                if len(pred_arrays)==1:
                    self.img = cv2.circle(self.img, (int(bbox_x*self.cell_size), int(bbox_y * self.cell_size)), 1, line_color, 1)
    
    def process_pred(self, pred):
        processed_pred = pred
        if (not self.true_labels):
            obj_prob, bbox_x, bbox_y, rel_bbox_h, rel_bbox_w = sigmoid(pred[..., 0:5])
            #rel_bbox_h = rel_bbox_w = (rel_bbox_h + rel_bbox_w)/2
            rel_bbox_h = rel_bbox_w = max(rel_bbox_h, rel_bbox_w)*1.5
            raw_probs = pred[...,5:]
            softmax_denominator = 0
            for raw_prob in raw_probs:
                softmax_denominator += exp(raw_prob)
            probs = [exp(raw_prob)/softmax_denominator for raw_prob in raw_probs]
            processed_pred = [obj_prob, bbox_x, bbox_y, rel_bbox_h, rel_bbox_w] + probs                       
        return processed_pred
    
    
    def calc_pixel_pos(self, i, bbox_x, bbox_y, rel_bbox_h, rel_bbox_w):
        
        # indices from 0 to 18 for rows and columns
        row_index = i//self.cells_per_side
        col_index = self.cells_per_side - ((row_index + 1) * self.cells_per_side - i)
        
        # Pixel: x, y
        bbox_mid_pix = (col_index * self.cell_size + 1) + int(self.cell_size * bbox_x), (row_index * self.cell_size + 1) + int(self.cell_size * bbox_y)
        upper_left_pix = int(bbox_mid_pix[0] - 0.5 * (rel_bbox_w * self.cell_size)), int(bbox_mid_pix[1] + 0.5 * (rel_bbox_h * self.cell_size))
        lower_right_pix = int(bbox_mid_pix[0] + 0.5 * (rel_bbox_w * self.cell_size)), int(bbox_mid_pix[1] - 0.5 * (rel_bbox_h * self.cell_size))
        
        return upper_left_pix, lower_right_pix
    
    
    
    def single_pred_array_to_arrays(self, predictions):
        pred_arrays = []
        for i in range(0, len(predictions), self.pred_array_length):
            pred_arrays += [predictions[i:i+self.pred_array_length]]
        return pred_arrays
