import os
import h5py
import numpy as np
from math import floor, exp
import cv2

PROJECT_DIR = os.pardir
DATASET_DIR = os.path.join(PROJECT_DIR, 'data', 'dataset')
MODEL_DIR = os.path.join(PROJECT_DIR, 'models')


def load_dataset(filename, set_type, normalize_images=True):
    assert set_type in ['train', 'dev', 'test']
    hdf5_file = h5py.File(os.path.join(DATASET_DIR, filename), 'r')
    X, y = hdf5_file["X_" + set_type][:], hdf5_file["y_" + set_type][:]
    if normalize_images:
        X /= 255.
    return X, y
    
def sigmoid(x):
    return 1/(1+np.exp(-1*x))

	
def calc_output_shape(input_size, kernel_size, no_filters, stride, padding=0):
    "for quadratic shapes" 
    output_side = floor(((input_size - kernel_size + 2 * padding) / stride) + 1)
    
    return (output_side, output_side, no_filters)


def identify_grid_cell(mid_x, mid_y, grid_cells_per_side, grid_cell_size):
    """Return the gridcell an identified object belongs to
    Grid cell enumeration starts with 0
    
      1,1               1, img_width
        -------------------
        |  0  |  1  |  2  |
        -------------------
        |  3  |  4  |  5  |                    In Pixel
        -------------------
        |  6  |  7  |  8  |
        -------------------
    img_height, 1       img_height, img_width
    """

    y_pos = int(mid_y / grid_cell_size)
    x_pos = int(mid_x / grid_cell_size)
    grid_cell_no = x_pos + y_pos * grid_cells_per_side
    grid_pix_00 = (y_pos * grid_cell_size, x_pos * grid_cell_size)
    #grid_pix_01 = (y_pos * self.grid_cell_size, (x_pos + 1) * self.grid_cell_size)
    #grid_pix_10 = ((y_pos + 1) * self.grid_cell_size, x_pos * self.grid_cell_size)
    #grid_pix_11 = ((y_pos + 1) * self.grid_cell_size, (x_pos + 1) * self.grid_cell_size)
    
    return grid_cell_no, grid_pix_00#, grid_pix_01, grid_pix_10, grid_pix_11


def get_bbox(obj, grid_cells_per_side, grid_cell_size, quadratic_bbox = True):
    """obj: info about detected object
    Returns the grid cell no of the object, its classification, and the bounding box information
    relative to the grid cell
    """
    classification, _, truncated, _, bndbox = obj.values()
    x_min, y_min, x_max, y_max = bndbox.values()
    x_min, y_min, x_max, y_max = int(x_min), int(y_min), int(x_max), int(y_max)
    mid_x, mid_y = (x_min + x_max)/2, (y_min + y_max)/2
    grid_cell_no, grid_pix_00 = identify_grid_cell(mid_x, mid_y, grid_cells_per_side, grid_cell_size)
    rel_mid_y = (mid_y - grid_pix_00[0]) / grid_cell_size
    rel_mid_x = (mid_x - grid_pix_00[1]) / grid_cell_size
    
    
    if quadratic_bbox:
        width, height = x_max - x_min, y_max - y_min
        width = height = (width + height) / 2
        rel_width = rel_height = width / grid_cell_size
        
    else:
        raise NotImplementedError
        
    return grid_cell_no, classification, rel_mid_x, rel_mid_y, rel_height, rel_width
    
    
def get_grid_cells_with_objects(objects_list, preferred_class, grid_cells_per_side, grid_cell_size):
    grid_cells_w_objects={}
    for obj in objects_list:
        grid_cell_no, classification, rel_mid_x, rel_mid_y, rel_height, rel_width = get_bbox(obj, grid_cells_per_side, grid_cell_size)
        
        # Prevent the assignment of two marbles to a grid cell
        if grid_cell_no in grid_cells_w_objects.keys():
            if ((grid_cells_w_objects[grid_cell_no][0] != preferred_class) & 
                (classification == preferred_class)):
                grid_cells_w_objects[grid_cell_no] = [classification, rel_mid_x, rel_mid_y, rel_height, rel_width]
            continue
        grid_cells_w_objects[grid_cell_no] = [classification, rel_mid_x, rel_mid_y, rel_height, rel_width]

    return grid_cells_w_objects
    
def get_grid_cell_size(im_width, im_height, grid_cells_per_side):
    assert im_width == im_height
    assert im_width % grid_cells_per_side == 0
    
    return im_width / grid_cells_per_side

    
def resize_image(im, aim_size=608, rotate=3):
    """Rotates image if necessary, resizes it to aim_size * aim_size
    and cuts it into pieces_per_side * pieces_per_side.
    Return a list with the Resized Image pieces
    """
    if (not (not rotate)):
        im = rotate_image(im, k = rotate)
    im_size = im.shape
    ratio = aim_size / max(im_size)
    im_size_new = (np.asarray(im_size) * ratio).astype(int)
    im_size_new[2] = 3
    resized_im = cv2.resize(im, (im_size_new[1], im_size_new[0]), interpolation=cv2.INTER_CUBIC)
    if im_size_new[0]<aim_size:
        resized_im = np.pad(resized_im, 
                            ((int((aim_size - im_size_new[0])/2), int((aim_size - im_size_new[0])/2)),(0, 0), (0,0)), 
                            'constant', constant_values=(0, 0))
    if im_size_new[1]<aim_size:
        resized_im = np.pad(resized_im, 
                            ((0, 0),(int((aim_size - im_size_new[1])/2), int((aim_size - im_size_new[1])/2)), (0,0)), 
                            'constant', constant_values=(0, 0))
    return resized_im
                            
                            
def cut_up_image(im, pieces_per_side):
    #padded_im = Image.new('RGB', (aim_size, aim_size))
    #padded_im.paste(resized_im, paste_coordinates)
    #list_of_image_pieces = []
    #for width in range(0, pieces_per_side):
    #    for height in range(0, pieces_per_side):
    #        box = (width * piece_size, height * piece_size, (width+1) * piece_size, (height+1) * piece_size)
    #        cropped = padded_im.crop(box)
    #        list_of_image_pieces += [cropped]
    raise NotImplementedError
    
def rotate_image(im, k=3):
    """Rotates image k times clockwise by 90°"""
    return np.rot90(im, k=k)