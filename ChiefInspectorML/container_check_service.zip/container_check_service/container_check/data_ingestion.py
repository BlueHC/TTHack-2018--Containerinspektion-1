import h5py
import os
import numpy as np
from math import ceil
PROJECT_DIR = os.pardir
DATASET_DIR = os.path.join(PROJECT_DIR, 'data', 'dataset')


def get_batches_no(filename, batch_size):
    with h5py.File(os.path.join(DATASET_DIR, filename), 'r') as hdf5_file:
        data_num = hdf5_file["X_train"].shape[0]
        batches_no = int(ceil(float(data_num)/batch_size))
        
        return batches_no


def data_generator(filename, batch_size, key, normalize=True):
    """Returns batches of data from a HDF5 file
    key is either "train", "dev" or "test"
    """
    hdf5_file = h5py.File(os.path.join(DATASET_DIR, filename), 'r')
    data_num = hdf5_file["X_" + key].shape[0]
    batches_no = int(ceil(float(data_num)/batch_size))
    while True:
        for i in range(batches_no):
            batch_start = i*batch_size
            batch_end = min((i+1)*batch_size, data_num)
            X_train = hdf5_file["X_" + key][batch_start:batch_end, ...]
            if normalize:
                X_train/=255.
            y_train = hdf5_file["y_" + key][batch_start:batch_end, ...]
            
            yield X_train, y_train
